<template>
	<view class="cate-item">
		<view class="item-group">
			<image :src="cateitem.src" mode="" style="width: 50upx;height: 50upx;"></image>
			<view style="font-size: 26upx;">{{cateitem.title}}</view>
		</view>
	</view>
</template>

<script>
	export default{
		props:['cateitem']
	}
</script>

<style>
	.cate-item{
		align-items: center;
		margin-bottom: 10upx;
	}
	.item-group{
		text-align: center;
	}
</style>
