<template>
	<view>
		<view class="uni-padding-wrap">
			<view class="page-section swiper">
				<view class="page-section-spacing">
					<swiper class="swiper" :indicator-dots="indicatorDots" :autoplay="autoplay" :interval="interval" :duration="duration">
						<swiper-item v-for="(swiper_item, index) in swipers" :key="index">
							<view class="swiper-item uni-bg-red">
								<image :src="swiper_item.src" style="width: 100%;" mode=""></image>
							</view>
						</swiper-item>
					</swiper>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		props:['swipers'],
		data() {
			return {
				indicatorDots: true,
				autoplay: true,
				interval: 3000,
				duration: 500
			}
		},
		onLoad() {
			uni.request({
				url: '../dev_data/swiper.json',
				success: res => {
					cconsole.log(res.data);
				}
			})
		}
	}
</script>

<style>
</style>
