<template>
	<view v-if="btnFlag"><image class="top_button" src="../../static/icon/top.svg" @click="toTop"></image></view>
</template>

<script>
export default {
	data() {
		return {
			btnFlag: ''
		};
	},
	mounted () {
	  window.addEventListener('scroll', this.scrollToTop)
	},
	destroyed () {
	  window.removeEventListener('scroll', this.scrollToTop)
	},
	methods:{
		// 返回顶部
		toTop() {
			uni.pageScrollTo({
				scrollTop: 0,
				duration: 300
			});
		},
		// 显示返回按钮
		scrollToTop () {
		    const that = this
		    let scrollTop = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop
		    that.scrollTop = scrollTop
		    if (that.scrollTop > 500) {
		      that.btnFlag = true
		    } else {
		      that.btnFlag = false
		    }
		}
	}
};
</script>

<style>
	.top_button {
		width: 80upx;
		height: 80upx;
		box-shadow: 5upx 5upx 7upx #f44e6b;
		border-radius: 100upx;
		position: fixed;
		bottom: 180upx;
		right: 25upx;
		background: #f8f8f8;
		opacity: 0.8;
		z-index: 2;
	}
</style>
