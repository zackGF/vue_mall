<template>
	<view>
		<view class="cart-list">
			<view style="border-bottom: 5upx solid #C0C0C0; margin-bottom: 20upx;" v-for="(item, index) in cartList" :key="index">
				<view class="cart-group">
					<view class="itemImage">
						<switch @change="switchChange" @click="switchCash(index)" />
						<image :src="item.src" mode=""></image>
					</view>
					<view class="itemDesc">
						<view class="title">{{ item.title }}</view>
						<view class="price" v-model="gPrice">{{ item.price }}</view>
					</view>
				</view>
				<view style="width: 100%;height: 1px; background: #F1F1F1; margin-bottom: 10upx;"></view>
				<!-- <view class="countnum">
					<view style="margin-right: 30upx;" @click="delitem(index)"><image style="width: 40upx;height: 40upx;" src="../../static/icon/trash.svg" mode=""></image></view>
					<text style="font-size: 30upx; margin-right: 20upx;">购买数量</text>
					<view class="numcount" @click="btnMinu(index)"><text>-</text></view>
					<input class="inputcount" type="number" v-model="item.amount" />
					<view class="numcount" @click="btnPlus(index)"><text>+</text></view>
				</view> -->
			</view>
		</view>
		<view class="order_tab">
			<view style="margin-right: 40upx;">￥：{{ totalPrice }}</view>
			<view style="margin-right: 40upx;"><button style="width: 150upx; height: 70upx; font-size: 30upx;" type="warn">结算</button></view>
		</view>
	</view>
</template>

<script>
export default {
	data() {
		return {
			hadOpen: false,
			gPrice: '',
			totalPrice: 0,
			itemPrice: 0,
			cartList: [],
			selid: []
		};
	},
	onLoad() {
		this.loadData();
		console.log(this.checked);
		// this.OnShowCartList();
	},
	methods: {
		async loadData() {
			// this.calc();
			this.OnShowCartList();
		},
		switchChange(e) {
			// console.log('switch2 发生 change 事件，携带值为', e.target.value);
			this.hadOpen = e.target.value;
		},

		switchCash(index) {
			if (this.hadOpen === true) {
				//
				// this.totalPrice += this.itemPrice;
				this.itemprice(index);
				this.totalPrice +=this.itemPrice
			} else {
				if (this.totalPrice <= 0) {
					this.totalPrice = 0;
				}
				this.totalPrice -= this.cartList[index].price * this.cartList[index].amount;
			}
		},

		OnShowCartList() {
			uni.request({
				url: '../../static/dev_data/cart.json',
				success: res => {
					this.cartList = res.data;
				}
			});
		},
		btnMinu(index) {
			if (this.cartList[index].amount <= 1) {
				this.cartList[index].amount == 1;
				this.itemprice(index);
				// this.calc()
			} else {
				this.cartList[index].amount--;
				this.itemprice(index);
				// this.calc()
			}
		},
		btnPlus(index) {
			this.cartList[index].amount++;
			this.itemprice(index);
			// this.calc()
		},
		itemprice(index) {
			if (this.hadOpen === true) {
				this.itemPrice = this.cartList[index].price * this.cartList[index].amount;
			}
			return;
			// console.log(this.itemPrice);
		},
		delitem(index) {
			this.cartList.splice(index, 1);
			// uni.hideLoading(index);
			this.totalPrice -= this.cartList[index].price * this.cartList[index].amount;
		},
		calc() {
			this.totalPrice = 0;
			let count = this.cartList.length;
			for (var i = 0; i < count; i++) {
				this.totalPrice += this.cartList[i].price * this.cartList.amount;
				console.log(this.totalPrice);
			}
		}
	}
};
</script>

<style>
.cart-list {
	margin-top: 20upx;
	margin-bottom: 190upx;
}
.cart-group {
	display: flex;
	flex-direction: row;
	margin-bottom: 20upx;
}

.itemImage {
	display: flex;
	flex-direction: row;
	justify-content: center;
	align-items: center;
	width: 300upx;
	margin: 0 20upx 0 20upx;
}
.itemImage image {
	width: 150upx;
	height: 150upx;
}
.itemDesc {
	padding: 10upx 0 0 0;
}
.title {
	font-size: 40upx;
	color: #333333;
	margin-bottom: 10upx;
}
.price {
	font-size: 40upx;
	color: #f44e6b;
}
.countnum {
	display: flex;
	flex-direction: row;
	justify-content: flex-end;
	margin: 0 30upx 0 0;
	align-items: center;
	margin-bottom: 10upx;
}
.numcount {
	margin: 0;
	background-color: #f5f5f5;
	width: 70upx;
	height: 70upx;
	line-height: 70upx;
	text-align: center;
	position: relative;
}
.inputcount {
	position: relative;
	background-color: #f5f5f5;
	width: 90upx;
	height: 70upx;
	text-align: center;
	padding: 0;
	font-size: 30upx;
}
.order_tab {
	display: flex;
	align-items: center;
	justify-content: flex-end;
	position: fixed;
	z-index: 90;
	margin-bottom: 110upx;
	bottom: 30upx;
	right: 2%;
	padding: 20upx;
	width: 70%;
	background: rgba(255, 255, 255, 0.8);
	box-shadow: 7upx 5upx 14upx #f44e6b;
	border-radius: 50upx;
}
</style>
