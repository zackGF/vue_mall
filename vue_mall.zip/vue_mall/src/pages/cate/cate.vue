<template>
	<view class="content_">
		<view class="left">
			<scroll-view scroll-y="true" class="left-side">
				<view class="f-item" v-for="item in flist" :key="item.id" :class="{ active: item.id === currentId }" @click="tabtap(item)">{{ item.name }}</view>
			</scroll-view>
		</view>
		<view class="right">
			<view class="right-side">
				<view class="item-group" v-for="item in slist" :key="item.id" @click="toPointGList(item.id)">
					<image :src="item.src" mode=""></image>
					<view class="text_name">{{item.name}}</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
export default {
	data() {
		return {
			flist: [],
			slist: [],
			currentId: 1
		};
	},
	onLoad() {
		this.OnShowCategory();
	},
	methods: {
		OnShowCategory() {
			uni.request({
				url: '../../static/dev_data/category.json',
				success: res => {
					// console.log(res.data);
					this.flist = res.data;
				}
			});
			uni.request({
				url:'../../static/dev_data/cate_list/1.json',
				success: res => {
					// console.log(res.data);
					this.slist = res.data;
				}
			})
		},
		tabtap(item) {
			this.currentId = item.id;
			uni.request({
				url:'../../static/dev_data/cate_list/'+item.id+'.json',
				success: res => {
					// console.log(res.data);
					this.slist = res.data;
				}
			})
		},
		toPointGList(item){
			let id = item.id
			uni.navigateTo({
				url:'../cate/catelist?id='+id
			})
		}
	}
};
</script>

<style>
.content_{
	display: flex;
	flex-direction: row;
}
.left {
	width: 200upx;
	height: 100%;
	border-right: 1px solid #f1f1f1;
	position: fixed;
	z-index: 1;
}
.f-item {
	display: flex;
	align-items: center;
	justify-content: center;
	width: 100%;
	height: 100upx;
	font-size: 28upx;
}

.active {
	color: #f44e6b;
	background: #f1f1f1;
	border-left: 5px solid #f44e6b;
	font-weight: bold;
}

.right{
	overflow: hidden;
	padding-left: 220upx;
}
.right-side{
	display: flex;
	flex-direction: row;
	flex-wrap: wrap;
	margin-top: 40upx;
}
.item-group{
	text-align: center;
	width: 160upx;
	margin-left: 10upx;
	margin-bottom: 40upx;
}
.item-group image{
	width: 120upx;
	height: 120upx;
	margin-bottom: 20upx;
}
.text_name{
	font-size: 24upx;
}
</style>
