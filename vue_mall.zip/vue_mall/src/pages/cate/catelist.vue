<template>
	<view>
		<view style="display: flex; justify-content: center; font-size: 40upx; padding: 40upx 0 40upx 0;width: 750upx;">
			<view style="width: 375upx; border: 1px solid #C8C7CC; text-align: center; padding: 10upx;border-radius: 15upx; color: #999999;">↓分类列表↓</view>
		</view>
		<view class="goods_list">
			<view class="goods_item" v-for="(goodsitem, index) in goodslist" :key="index" @click="toProduct(goodsitem)">
				<view style="text-align: center;width: 99%;border: 1px solid #C8C7CC;padding-top: 10upx;border-radius: 20upx;">
					<image style="width: 290upx;height: 290upx;" :src="goodsitem.src" mode=""></image>
				</view>
				<table>
					<tr>
						<td rowspan="2"><view style="font-size: 24upx; padding: 5upx 2upx;background: #f44e6b;color: #FFF;border-radius: 10upx;text-align: center;">自营</view></td>
						<td>
							<view style="font-size: 30upx;">{{ goodsitem.title }}</view>
						</td>
					</tr>
					<tr>
						<td>
							<view style="font-size: 30upx;color: #DC143C;">￥:{{ goodsitem.price }}</view>
						</td>
					</tr>
				</table>
			</view>
		</view>
		<ToTop></ToTop>
	</view>
</template>

<script>
import ToTop from '../../components/ToTop.vue';
export default {
	data() {
		return {
			goodslist: []
		};
	},
	onLoad() {
		this.OnShowGoodsList();
	},
	methods: {
		OnShowGoodsList() {
			uni.request({
				url: '../../static/dev_data/goods_list.json',
				success: res => {
					// console.log(res.data);
					this.goodslist = res.data;
				}
			});
		},
		toProduct(item) {
			let id = item.id;
			uni.navigateTo({
				url: '../product/product?id=' + id
			});
		}
	},
	components:{
		ToTop
	}
};
</script>

<style>
.goods_list {
	display: flex;
	flex-direction: row;
	justify-content: space-around;
	flex-wrap: wrap;
}

.goods_item {
	width: 48%;
	margin-bottom: 30upx;
	/* background-color: #007AFF; */
}
</style>
