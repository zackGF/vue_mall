<template>
	<view class="content">
		<!-- 轮播图  开始 -->
		<view class="uni-padding-wrap" style="z-index: 1;">
			<view class="page-section swiper">
				<view class="page-section-spacing">
					<swiper style="height: 380upx;" class="swiper" :indicator-dots="indicatorDots" :autoplay="autoplay" :interval="interval" :duration="duration">
						<swiper-item v-for="(swiper_item, index) in swipers" :key="index" @click="toProduct(swiper_item)">
							<view class="swiper-item uni-bg-red" style="padding: 10upx;">
								<image :src="swiper_item.src" style="width: 100%;height: 360upx;border-radius: 15upx;" mode=""></image>
							</view>
						</swiper-item>
					</swiper>
				</view>
			</view>
		</view>
		<!-- 轮播图 结束 -->
		<view class="pact-icon">
			<view class="u-list">
				<view class="u-li">
					<image src="../../static/index/sure_icon.svg" mode="" class="sure_icon"></image>
					<text>7天无理由</text>
				</view>
				<view class="u-li">
					<image src="../../static/index/sure_icon.svg" mode="" class="sure_icon"></image>
					<text>180天质保</text>
				</view>
				<view class="u-li">
					<image src="../../static/index/sure_icon.svg" mode="" class="sure_icon"></image>
					<text>假一赔十</text>
				</view>
				<view class="u-li">
					<image src="../../static/index/sure_icon.svg" mode="" class="sure_icon"></image>
					<text>百家自营</text>
				</view>
			</view>
		</view>

		<!-- 首页 大分类 -->
		<view class="index-cate">
			<view v-for="cateitem in indexcate" :key="cateitem.id" style="width: 18%;" @click="toPointGList(cateitem)"><MallIndexCate :cateitem="cateitem"></MallIndexCate></view>
		</view>
		<!-- 每日精选 -->
		<view class="daily_goods">时下精品</view>
		<view class="goods_list">
			<view class="goods_item" v-for="(goodsitem, index) in goodslist" :key="index" @click="toProduct(goodsitem)">
				<view style="text-align: center;width: 99%;border: 1px solid #C8C7CC;padding-top: 10upx;border-radius: 20upx;">
					<image style="width: 290upx;height: 290upx;" :src="goodsitem.src" mode=""></image>
				</view>
				<table>
					<tr>
						<td rowspan="2"><view style="font-size: 24upx; padding: 5upx 2upx;background: #f44e6b;color: #FFF;border-radius: 10upx;text-align: center;">自营</view></td>
						<td>
							<view style="font-size: 30upx;">{{ goodsitem.title }}</view>
						</td>
					</tr>
					<tr>
						<td>
							<view style="font-size: 30upx;color: #DC143C;">￥:{{ goodsitem.price }}</view>
						</td>
					</tr>
				</table>
			</view>
		</view>
		<ToTop></ToTop>
	</view>
</template>

<script>
import MallIndexCate from '../../components/MallIndexCate.vue';
import ToTop from '../../components/ToTop.vue'
export default {
	data() {
		return {
			indicatorDots: true,
			autoplay: true,
			interval: 3000,
			duration: 500,
			swipers: [],
			indexcate: [],
			goodslist: []
		};
	},
	onLoad() {
		this.OnShowSwiper();
		this.OnShowIndexCate();
		this.OnShowGoodsList();
	},
	mounted () {
	  window.addEventListener('scroll', this.scrollToTop)
	},
	destroyed () {
	  window.removeEventListener('scroll', this.scrollToTop)
	},
	methods: {
		// 显示轮播图
		OnShowSwiper() {
			uni.request({
				url: '../../static/dev_data/swiper.json',
				success: res => {
					this.swipers = res.data;
				}
			});
		},
		// 显示首页-大类别
		OnShowIndexCate() {
			uni.request({
				url: '../../static/dev_data/index_cate.json',
				success: res => {
					// console.log(res.data);
					this.indexcate = res.data;
				}
			});
		},
		// 显示商品类型
		OnShowGoodsList() {
			uni.request({
				url: '../../static/dev_data/goods_list.json',
				success: res => {
					// console.log(res.data);
					this.goodslist = res.data;
				}
			});
		},
		// 商品详情页
		toProduct(item) {
			let id = item.id;
			uni.navigateTo({
				url: '../product/product?id=' + id
			});
		},
		// 类别列表页
		toPointGList(item) {
			let id = item.id;
			uni.navigateTo({
				url: '../cate/catelist?id=' + id
			});
		}
	},
	components: {
		MallIndexCate,
		ToTop
	}
};
</script>

<style>
.u-list {
	display: flex;
	flex-direction: row;
	justify-content: space-around;
}

.u-li {
	display: flex;
	align-items: center;
}

.pact-icon {
	margin-top: 15upx;
	border-bottom: #c8c7cc 1px solid;
	padding-bottom: 10upx;
}

.index-cate {
	display: flex;
	flex-direction: row;
	justify-content: space-around;
	margin-top: 10px;
	flex-wrap: wrap;
}

.pact-icon text {
	margin-left: 10upx;
	font-size: 20upx;
	color: #c8c7cc;
	font-weight: bold;
}

.sure_icon {
	width: 30upx;
	height: 30upx;
}

.daily_goods {
	border-left: 15upx solid #ffd700;
	padding: 15upx 10upx;
	align-items: center;
	border-radius: 15upx;
	margin: 40upx 30upx;
}

.goods_list {
	display: flex;
	flex-direction: row;
	justify-content: space-around;
	flex-wrap: wrap;
}

.goods_item {
	width: 48%;
	margin-bottom: 30upx;
	/* background-color: #007AFF; */
}
</style>
