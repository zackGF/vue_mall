<template>
	<view>
		<!-- 头像区域 -->
		<view class="icon-area">
			<image class="item_icon" src="../../static/icon/me/user_def.svg" mode=""></image>
			<view style="font-size: 35upx;">用户：*****</view>
		</view>
		<view class="order_tab tab_base">
			<view>
				<image class="item_icon" src="../../static/icon/me/order.svg" mode=""></image>
				<text>订单</text>
			</view>
			<image class="item_icon" src="../../static/icon/me/go.svg" mode=""></image>
		</view>
		<view class="discount tab_base">
			<view>
				<image class="item_icon" src="../../static/icon/me/discount.svg" mode=""></image>
				<text>优惠券</text>
			</view>
			<image class="item_icon" src="../../static/icon/me/go.svg" mode=""></image>
		</view>
		<view class="address tab_base">
			<view>
				<image class="item_icon" src="../../static/icon/me/address.svg" mode=""></image>
				<text>地址管理</text>
			</view>
			<image class="item_icon" src="../../static/icon/me/go.svg" mode=""></image>
		</view>
		<view class="customer tab_base">
			<view>
				<image class="item_icon" src="../../static/icon/me/customer.svg" mode=""></image>
				<text>客服</text>
			</view>
			<image class="item_icon" src="../../static/icon/me/go.svg" mode=""></image>
		</view>
		<view class="about tab_base">
			<view>
				<image class="item_icon" src="../../static/icon/me/team.svg" mode=""></image>
				<text>关于我们</text>
			</view>
			<image class="item_icon" src="../../static/icon/me/go.svg" mode=""></image>
		</view>
		<!-- 退出按钮 -->
		<view class="bottom">
			<button type="warn">退出</button>
		</view>
	</view>
</template>

<script>
export default {
	data() {
		return {};
	},
	methods: {}
};
</script>

<style>
text{
	margin-left: 20upx;
	color: #555555
}
.tab_base {
	display: flex;
	align-items: center;
	border-bottom: 1px solid #f1f1f1;
	justify-content: space-between;
	padding: 20upx;
}
.item_icon {
	width: 35upx;
	height: 35upx;
}
.icon-area {
	width: 100%;
	height: 300upx;
	text-align: center;
	border-bottom: 6upx solid #c8c7cc;
}
.icon-area image {
	width: 200upx;
	height: 200upx;
	border-radius: 70upx;
	margin-top: 20upx;
}
.bottom{
	width: 100%;
	margin-top: 250upx;
	margin-bottom: 50upx;
}
.bottom button{
	width: 375upx;
}
</style>
