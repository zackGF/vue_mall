<template>
	<view>
		<!-- 轮播图  开始 -->
		<view class="uni-padding-wrap" style="z-index: 1;">
			<view class="page-section swiper">
				<view class="page-section-spacing">
					<swiper
						style="height: 500upx; text-align: center;"
						class="swiper"
						:indicator-dots="indicatorDots"
						:autoplay="autoplay"
						:interval="interval"
						:duration="duration"
					>
						<swiper-item v-for="(item, index) in goodsinfo.goods_img" :key="index">
							<view class="swiper-item" style="padding: 10upx;"><image :src="item.link" style="width: 450upx; height: 450upx;"></image></view>
						</swiper-item>
					</swiper>
				</view>
			</view>
		</view>
		<!-- 轮播图 结束 -->
		<view class="title base">{{ goodsinfo.title }}</view>
		<view class="goods_price base">￥:{{ goodsinfo.price }}</view>
		<view class="goods_self base">
			<view style="align-items: center;">
				<image style="width: 28upx;height: 28upx;" src="../../static/index/sure_icon.svg" mode=""></image>
				<text style="font-size: 30upx; color: #f44e6b; margin-left: 5upx;">服务保障</text>
			</view>
			<view style="font-size: 28upx;color: #808080;">全场包邮</view>
			<view style="font-size: 28upx;color: #808080;">24H发货</view>
		</view>

		<view class="base">
			<view style="display: flex;flex-direction: row;justify-content: center;align-items: center;">
				<view class="xian"></view>
				<text style="font-size: 28upx;margin: 0 10upx 0 10upx;">商品详情</text>
				<view class="xian_"></view>
			</view>
			<view class="info_tab">
				<table>
					<tr>
						<td>商品名称</td>
						<td>{{ goodsinfo.goods_info.name_ }}</td>
					</tr>
					<tr>
						<td>商品编号</td>
						<td>{{ goodsinfo.goods_info.g_num }}</td>
					</tr>
					<tr>
						<td>摄像头</td>
						<td>{{ goodsinfo.goods_info.sec }}</td>
					</tr>
					<tr>
						<td>屏幕</td>
						<td>{{ goodsinfo.goods_info.dsp }}</td>
					</tr>
					<tr>
						<td>容量</td>
						<td>{{ goodsinfo.goods_info.rom }}</td>
					</tr>
					<tr>
						<td>系统</td>
						<td>{{ goodsinfo.goods_info.system }}</td>
					</tr>
				</table>
			</view>
		</view>
		<view class="imggroup">
			<view class="info_img" v-for="(item, index) in goodsinfo.goods_img" :key="index"><img :src="item.link" alt="" /></view>
		</view>
		<view class="bottom_tab">
			<view class="cart_view">
				<image src="../../static/icon/tabbar/car_def.png" mode=""></image>
				<text style="font-size: 24upx;color: #cdcdcd;">购物车</text>
			</view>
			<view style="margin-left: 10upx;"><button style="color: #F0AD4E; background: #FFF; border: 1px solid #F0AD4E;">加入购物车</button></view>
			<view style="margin-left: 10upx;"><button style="background: #F44E6B;color: #FFF;">立即购买</button></view>
		</view>
		<ToTop></ToTop>
	</view>
</template>

<script>
	import ToTop from '../../components/ToTop.vue';
export default {
	data() {
		return { indicatorDots: true, autoplay: true, interval: 3000, duration: 500, goodsinfo: [] };
	},
	onLoad() {
		this.OnShowGoodsInfo();
	},
	methods: {
		OnShowGoodsInfo() {
			uni.request({
				url: '../../static/dev_data/goods_info.json',
				success: res => {
					// console.log(res.data.goods_img);
					this.goodsinfo = res.data;
				}
			});
		}
	},
	components:{
		ToTop
	}
};
</script>

<style>
.base {
	margin-bottom: 20upx;
	margin-left: 3%;
}
.title {
	font-size: 35upx;
}
.goods_price {
	color: #f44e6b;
	font-size: 40upx;
	font-weight: bold;
}
.goods_self {
	display: flex;
	flex-direction: row;
	justify-content: space-around;
	align-items: center;
	width: 92%;
	background: #f8f8f8;
	padding: 1%;
	border-radius: 15upx;
}
.xian {
	height: 2px;
	width: 260upx;
	background: -webkit-linear-gradient(left, rgba(255, 255, 255, 0.5), #f44e6b);
	/* background: linear-gradient(to right, rgba(255, 255, 255, 0),#5DDDD3,rgba(255,255,255,0)); */
}
.xian_ {
	height: 2px;
	width: 260upx;
	background: -webkit-linear-gradient(left, #f44e6b, rgba(255, 255, 255, 0.5));
}
.info_tab {
	display: flex;
	align-items: center;
	justify-content: center;
}
.info_tab table {
	font-size: 30upx;
	color: #999999;
}
.imggroup {
	text-align: center;
	margin-bottom: 120upx;
}
.info_img img {
	width: 700upx;
	width: 700upx;
}
.bottom_tab {
	display: flex;
	align-items: center;
	justify-content: center;
	position: fixed;
	z-index: 999;
	bottom: 0;
	padding: 20upx;
	width: 90%;
	background: rgba(255,255,255,0.8);
	margin: 2%;
	box-shadow: 7upx 5upx 14upx #C8C7CC;
	border-radius: 50upx;
}
.cart_view {
	display: flex;
	flex-direction: column;
}
.bottom_tab image {
	width: 50upx;
	height: 50upx;
}
.bottom_tab button {
	width: 240upx;
	height: 80upx;
	font-size: 30upx;
}
</style>
